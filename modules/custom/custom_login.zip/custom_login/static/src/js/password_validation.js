odoo.define('custom_login.password_validation', function(require) {
    "use strict";

    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('passwordForm');
        if (!form) return;

        form.addEventListener('submit', function(event) {
            const newPasswordField = document.getElementById('new_password');
            const confirmPasswordField = document.getElementById('confirm_password');

            if (!newPasswordField || !confirmPasswordField) return;

            const newPassword = newPasswordField.value.trim();
            const confirmPassword = confirmPasswordField.value.trim();

            // Check if new password matches confirm password
            if (newPassword !== confirmPassword) {
                event.preventDefault();
                alert("New Password and Confirm Password do not match!");
                confirmPasswordField.focus();
                return false;
            }

            // Extra: minimum length
            if (newPassword.length < 8) {
                event.preventDefault();
                alert("Password must be at least 8 characters long");
                newPasswordField.focus();
                return false;
            }

            // Optional: check pattern (uppercase, lowercase, number)
            const pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
            if (!pattern.test(newPassword)) {
                event.preventDefault();
                alert("Password must contain at least 8 characters, including uppercase, lowercase, and a number");
                newPasswordField.focus();
                return false;
            }
        });
    });
});
