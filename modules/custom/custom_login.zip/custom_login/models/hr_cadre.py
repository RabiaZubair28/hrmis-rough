from odoo import models, fields, api



class HRCadre(models.Model):
    _name = "hr.cadre"
    _description = "Cadre"
    name = fields.Char(required=True)

class HRCadreMapping(models.Model):
    _name = "hr.cadre.mapping"
    _description = "Cadre → Section Officers"
    cadre_id = fields.Many2one('hrmis.user.profile', required=True)
    so_ids = fields.Many2many('res.users', string="Section Officers")


